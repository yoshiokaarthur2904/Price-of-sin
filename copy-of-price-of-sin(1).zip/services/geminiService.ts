
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getForestSpiritMessage(day: number, energy: number): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are the Forest Spirit of Emerald Valley. A cozy, pixel-art farming game. 
      The player is on day ${day} and has ${energy} energy left.
      Give them a short, wise, and mysterious one-sentence piece of advice or flavor text. 
      Keep it under 20 words. Use a friendly but mystical tone.`,
    });
    return response.text || "The soil whispers of growth...";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The forest remains silent for now.";
  }
}

export async function getCropLore(cropName: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a funny and cozy "Stardew Valley" style description for a crop called "${cropName}". Max 15 words.`,
    });
    return response.text || "A humble vegetable from the earth.";
  } catch (error) {
    return "Tastes like home.";
  }
}
