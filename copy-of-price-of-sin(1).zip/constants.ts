
import { CropType } from './types';

export const GRID_SIZE = 10;
export const MAX_ENERGY = 100;

export const CROPS_DATA: Record<CropType, { name: string; days: number; sellPrice: number; icon: string }> = {
  parsnip: { name: 'Parsnip', days: 4, sellPrice: 35, icon: '🥕' },
  kale: { name: 'Kale', days: 6, sellPrice: 110, icon: '🥬' },
  cauliflower: { name: 'Cauliflower', days: 12, sellPrice: 175, icon: '🥦' },
  potato: { name: 'Potato', days: 6, sellPrice: 80, icon: '🥔' },
};

export const INITIAL_INVENTORY = [
  { id: '1', name: 'Hoe', type: 'tool', icon: '⛏️', count: 1 },
  { id: '2', name: 'Watering Can', type: 'tool', icon: '💧', count: 1 },
  { id: '3', name: 'Parsnip Seeds', type: 'seed', cropType: 'parsnip', icon: '🌱', count: 15 },
  { id: '4', name: 'Potato Seeds', type: 'seed', cropType: 'potato', icon: '🌿', count: 5 },
];
