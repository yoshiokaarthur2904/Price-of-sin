
export type CropType = 'parsnip' | 'kale' | 'cauliflower' | 'potato';
export type Direction = 'up' | 'down' | 'left' | 'right';

export interface Crop {
  type: CropType;
  growthStage: number; // 0 to 3
  isWatered: boolean;
  daysToGrow: number;
}

export interface TileState {
  id: string;
  type: 'grass' | 'soil' | 'water';
  crop: Crop | null;
  isWatered: boolean;
}

export interface InventoryItem {
  id: string;
  name: string;
  type: 'seed' | 'tool' | 'crop';
  cropType?: CropType;
  icon: string;
  count: number;
}

export interface Player {
  x: number; // Grid coordinate (float)
  y: number; // Grid coordinate (float)
  direction: Direction;
  isMoving: boolean;
  frame: number; // For animation
  isAttacking: boolean;
  isDefending: boolean;
}

export interface GameState {
  money: number;
  day: number;
  energy: number;
  time: string;
  inventory: InventoryItem[];
  selectedSlot: number;
  tiles: TileState[];
  player: Player;
}
