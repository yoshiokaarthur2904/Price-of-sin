
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GameState, TileState, InventoryItem, Direction } from './types';
import { GRID_SIZE, MAX_ENERGY, INITIAL_INVENTORY } from './constants';
import { getForestSpiritMessage } from './services/geminiService';

// --- INTRO SCRIPTS ---
const INTRO_SCRIPT = {
  es: [
    "Había un hombre llamado Sam.", "Un criminal de alta categoría.", "Durante años vivió del robo,\ndel engaño y de la violencia.", "No por necesidad.\nFue por decisión propia.", "La ley, como siempre, terminó alcanzándolo.\n\nSam pasó años en prisión, viendo el mundo a través de rejas y recuerdos.",
    "Al salir, el aire era distinto.", "Por primera vez en años,\nSam no pensó en huir ni en delinquir.", "Pensó en su esposa,\npensó en su hija.", "Pensó en volver a casa.", "Pero el destino no le concedió\nni siquiera ese trayecto.",
    "El autobús en el que viajaba nunca llegó.", "Un accidente. Hierro retorcido.\nGritos. Muerte.",
    "Varias personas perdieron la vida aquel día.", "Sam no murió… pero tampoco despertó.", "Fue trasladado de urgencia al hospital.", "Su corazón latía.\nSus pulmones respiraban.", "Pero su mente estaba atrapada\nen la oscuridad.",
    "Entro en estado de coma.", "Un lugar donde el tiempo se disuelve...",
    "Entonces, Sam abrió los ojos.", "No estaba en un hospital.\nNo había máquinas. No había dolor.", "Solo sombras. Y una figura frente a él.", "—No temas —dijo la voz—.\n—No has muerto… pero tampoco estás vivo.", "Era Virgilio. El poeta. El guía del Infierno.", "Virgilio le reveló la verdad:\nEl cuerpo de Sam yace inmóvil en una cama.", "Su alma ha sido arrastrada a un juicio distinto.\nUn juego entre la vida y la muerte.",
    "—Deseaste volver con tu familia —le dijo—.", "—Pero ningún hombre cargado de tantos pecados\nregresa a la luz sin pagar su deuda.", "Si Sam quería despertar...\nsi quería volver a ver a su esposa...", "Debía descender.", "Cruzaría el Infierno de Dante.\nCírculo por círculo. Pecado por pecado.", "Cada castigo reflejaría una decisión que tomó en vida.", "—Si fallas —advirtió Virgilio—,\ntu cuerpo seguirá respirando… hasta que deje de hacerlo.", "—Pero si atraviesas todo el Infierno...\npodrás regresar.", "Sam miró el abismo frente a él.", "Por primera vez, no tuvo miedo de morir.\nTuvo miedo de no volver a vivir.", "Y dio el primer paso hacia el Infierno."
  ],
  en: [
    "There was a man named Sam.", "A high-profile criminal.", "For years he lived off theft,\ndeceit, and violence.", "Not out of necessity.\nIt was by choice.", "The law, as always, eventually caught up with him.\n\nSam spent years in prison, watching the world through bars and memories.",
    "Upon leaving, the air was different.", "For the first time in years,\nSam didn't think about fleeing or offending.", "He thought of his wife.\nHe thought of his daughter.", "He thought of going home.", "But fate did not grant him\neven that journey.",
    "The bus he was traveling on never arrived.", "An accident. Twisted iron.\nScreams. Death.",
    "Several people lost their lives that day.", "Sam did not die... but he didn't wake up either.", "He was rushed to the hospital.", "His heart beat.\nHis lungs breathed.", "But his mind was trapped\nin darkness.",
    "COMA.", "A place where time dissolves...",
    "Then, Sam opened his eyes.", "He wasn't in a hospital.\nThere were no machines. No pain.", "Only shadows. And a figure in front of him.", "—Do not fear —said the voice—.\n—You have not died... but you are not alive either.", "It was Virgil. The poet. The guide of Hell.", "Virgil revealed the truth:\nSam's body lies motionless in a bed.", "His soul has been dragged to a different trial.\nA game between life and death.",
    "—You wished to return to your family —he said—.", "—But no man burdened with so many sins\nreturns to the light without paying his debt.", "If Sam wanted to wake up...\nif he wanted to see his wife again...", "He had to descend.", "He would cross Dante's Inferno.\nCircle by circle. Sin by sin.", "Each punishment would reflect a decision he made in life.", "—If you fail —Virgil warned—,\nyour body will continue breathing... until it stops.", "—But if you traverse all of Hell...\nyou may return.", "Sam looked at the abyss before him.", "For the first time, he was not afraid of dying.\nHe was afraid of never living again.", "And he took the first step into Hell."
  ]
};

// --- CONSTANTS FOR MAP ---
const CANVAS_W = 640; 
const CANVAS_H = 360;

// Centralized obstacle definitions for consistency between render and physics
const OBSTACLES = [
    // Trees (x, y, radius) - Positioned more naturally
    { x: 60, y: 100, r: 35, type: 'tree' },
    { x: 140, y: 300, r: 40, type: 'tree' },
    { x: 560, y: 140, r: 35, type: 'tree' },
    { x: 480, y: 320, r: 35, type: 'tree' },
    { x: 30, y: 330, r: 25, type: 'tree' },
    { x: 600, y: 40, r: 30, type: 'tree' },
    
    // Decorative Props from reference image
    { x: 200, y: 120, r: 15, type: 'sign' }, // Wooden Sign
    { x: 380, y: 200, r: 20, type: 'shrine' }, // Stone Shrine/Lantern
    { x: 450, y: 250, r: 20, type: 'chest' }, // Wooden Chest
    
    // Bushes
    { x: 90, y: 220, r: 15, type: 'bush' },
    { x: 530, y: 240, r: 15, type: 'bush' },
];

// --- PIXEL ART CANVAS COMPONENT ---

interface PixelCanvasProps {
  mode: 'title' | 'game' | 'intro';
  introIndex?: number;
}

const PixelCanvas: React.FC<PixelCanvasProps> = ({ mode, introIndex = 0 }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    canvas.width = CANVAS_W;
    canvas.height = CANVAS_H;

    let frame = 0;
    let animationId: number;

    let scene = 'default';
    if (mode === 'intro') {
      if (introIndex <= 4) scene = 'prison_sunrise';
      else if (introIndex <= 9) scene = 'bus_ride';
      else if (introIndex <= 11) scene = 'crash';
      else if (introIndex <= 16) scene = 'hospital_coma';
      else if (introIndex <= 18) scene = 'darkness';
      else if (introIndex <= 25) scene = 'void';
      else scene = 'abyss';
    } else if (mode === 'title') {
      scene = 'title';
    } else if (mode === 'game') {
      scene = 'limbo';
    }

    // Particles for Intro
    interface Particle { x: number; y: number; size: number; speedY: number; speedX: number; opacity: number; }
    const particles: Particle[] = [];
    for(let i=0; i<50; i++) {
        particles.push({
            x: Math.random() * CANVAS_W,
            y: Math.random() * CANVAS_H,
            size: Math.random() * 4 + 1,
            speedY: -(Math.random() * 1 + 0.2), 
            speedX: (Math.random() - 0.5) * 1,
            opacity: Math.random() * 0.5 + 0.1,
        });
    }

    const draw = () => {
      frame++;
      const W = CANVAS_W;
      const H = CANVAS_H;

      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, W, H);

      if (scene === 'limbo') {
         // --- REFERENCE IMAGE STYLE (Slime RPG Style) ---
         // "Large Square Pixels" simulated by P=2
         const P = 2; 

         // --- PALETTE (Olive Green & Grey Stone) ---
         const C_GRASS_BG = '#6a8535'; // Olive green base
         const C_GRASS_SHADOW = '#59702b'; // Darker patches
         const C_GRASS_LIGHT = '#8ea346'; // Lighter tufts
         
         const C_STONE_MAIN = '#8b93af'; // Blue-grey stone slab
         const C_STONE_SHADOW = '#636b82'; // Dark stone edge
         const C_STONE_LIGHT = '#aeb5cc'; // Light stone edge
         
         const C_WOOD = '#8a5038'; // Reddish brown
         const C_WOOD_DARK = '#5e3626';
         
         const C_TREE_LEAVES_DARK = '#4d6932'; // Olive dark
         const C_TREE_LEAVES_LIGHT = '#6d8c3e'; // Olive light
         const C_TREE_TRUNK = '#756048'; // Greyish brown

         // 1. Base Ground (Olive Green)
         ctx.fillStyle = C_GRASS_BG;
         ctx.fillRect(0, 0, W, H);
         
         // 2. Texture (Large faint squares for grid feel)
         ctx.fillStyle = C_GRASS_SHADOW;
         for(let i=0; i<W; i+=32) {
             for(let j=0; j<H; j+=32) {
                 if ((i+j)%64 === 0) ctx.fillRect(i, j, P, P);
             }
         }

         // 3. Stone Slab Path (Broken Grid Style)
         const drawStoneSlab = (x: number, y: number, w: number, h: number) => {
             // Main slab
             ctx.fillStyle = C_STONE_MAIN;
             ctx.fillRect(x, y, w, h);
             // Highlight (Top/Left)
             ctx.fillStyle = C_STONE_LIGHT;
             ctx.fillRect(x, y, w, P);
             ctx.fillRect(x, y, P, h);
             // Shadow (Bottom/Right)
             ctx.fillStyle = C_STONE_SHADOW;
             ctx.fillRect(x, y+h-P, w, P);
             ctx.fillRect(x+w-P, y, P, h);
             
             // Cracks (Random)
             if (Math.random() > 0.8) {
                 ctx.fillStyle = C_STONE_SHADOW;
                 ctx.fillRect(x+P*2, y+P*2, P, P);
                 ctx.fillRect(x+P*3, y+P*3, P, P);
             }
         };

         // Generate path grid
         const pathTiles = [];
         const gridSize = 24; // Size of stones
         const gap = 4; // Gap between stones (grass showing)
         
         // Vertical Path
         for(let y=0; y<H; y+=gridSize+gap) {
            // Main path
             if (Math.random() > 0.1) pathTiles.push({x: W/2 - 20, y, w: gridSize, h: gridSize});
             if (Math.random() > 0.1) pathTiles.push({x: W/2 + 10, y, w: gridSize, h: gridSize});
             // Stray tiles
             if (Math.random() > 0.8) pathTiles.push({x: W/2 - 50, y, w: gridSize, h: gridSize});
         }
         // Horizontal Path
         for(let x=0; x<W; x+=gridSize+gap) {
             if (Math.abs(x - W/2) > 60) { // Don't overwrite center too much
                 if (Math.random() > 0.1) pathTiles.push({x: x, y: H/2 + 20, w: gridSize, h: gridSize});
                 if (Math.random() > 0.1) pathTiles.push({x: x, y: H/2 - 10, w: gridSize, h: gridSize});
             }
         }

         // Draw the path tiles
         pathTiles.forEach(t => {
             drawStoneSlab(t.x, t.y, t.w, t.h);
         });


         // 4. Grass Decoration (Tufts & Flowers)
         for(let i=0; i<100; i++) {
             // Deterministic random positions
             const x = (i * 137) % W;
             const y = (i * 243) % H;
             
             // Avoid path areas roughly
             const isPath = Math.abs(x - W/2) < 60 || Math.abs(y - H/2) < 40;
             
             if (!isPath) {
                 if (i % 5 === 0) {
                     // White Flower
                     ctx.fillStyle = '#fff';
                     ctx.fillRect(x, y, P, P);
                     ctx.fillStyle = '#d4d4d4'; // Stem/Shadow
                     ctx.fillRect(x, y+P, P, P);
                 } else {
                     // Grass Tuft
                     ctx.fillStyle = C_GRASS_SHADOW;
                     ctx.fillRect(x, y+P, P, P*2);
                     ctx.fillStyle = C_GRASS_LIGHT;
                     ctx.fillRect(x, y, P, P); // Tip
                     ctx.fillRect(x+P, y+P, P, P); // Side
                 }
             }
         }


         // 5. Props & Obstacles
         
         const drawTree = (x: number, y: number, r: number) => {
             // Shadow
             ctx.fillStyle = 'rgba(0,0,0,0.2)';
             ctx.beginPath(); ctx.ellipse(x, y+10, r, r/2, 0, 0, Math.PI*2); ctx.fill();
             
             // Trunk (Birch-like or grey-brown)
             ctx.fillStyle = '#8c7b66';
             ctx.fillRect(x-P*2, y-r/2, P*4, r);
             ctx.fillStyle = '#5e4b35'; // Dark line
             ctx.fillRect(x+P, y-r/2, P, r);

             // Leaves (Rounded blobs, solid color)
             ctx.fillStyle = C_TREE_LEAVES_DARK;
             ctx.beginPath(); ctx.arc(x, y-r, r, 0, Math.PI*2); ctx.fill();
             ctx.beginPath(); ctx.arc(x-r/2, y-r+10, r*0.6, 0, Math.PI*2); ctx.fill();
             ctx.beginPath(); ctx.arc(x+r/2, y-r+10, r*0.6, 0, Math.PI*2); ctx.fill();
             
             // Highlight
             ctx.fillStyle = C_TREE_LEAVES_LIGHT;
             ctx.beginPath(); ctx.arc(x, y-r-5, r*0.7, 0, Math.PI*2); ctx.fill();
         };

         const drawBush = (x: number, y: number, r: number) => {
             ctx.fillStyle = 'rgba(0,0,0,0.2)';
             ctx.beginPath(); ctx.ellipse(x, y+5, r, r/3, 0, 0, Math.PI*2); ctx.fill();
             
             ctx.fillStyle = C_TREE_LEAVES_DARK;
             ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI*2); ctx.fill();
             ctx.fillStyle = C_TREE_LEAVES_LIGHT;
             ctx.beginPath(); ctx.arc(x, y-4, r*0.6, 0, Math.PI*2); ctx.fill();
             
             // Little berries?
             ctx.fillStyle = '#e0c055';
             if (x%2===0) ctx.fillRect(x-4, y, P, P);
             if (y%2===0) ctx.fillRect(x+4, y-4, P, P);
         };

         const drawSign = (x: number, y: number) => {
             // Post
             ctx.fillStyle = C_WOOD_DARK;
             ctx.fillRect(x-P, y, P*2, 20);
             // Signboard
             ctx.fillStyle = C_WOOD;
             ctx.fillRect(x-15, y-15, 30, 15);
             ctx.fillStyle = C_WOOD_DARK; // Border/Shadow
             ctx.fillRect(x-15, y-15, 30, P); // Top
             ctx.fillRect(x-15, y, 30, P); // Bottom
             ctx.fillRect(x-15, y-15, P, 15); // Left
             ctx.fillRect(x+15-P, y-15, P, 15); // Right
             // Text scribble
             ctx.fillStyle = '#5e3626';
             ctx.fillRect(x-10, y-10, 10, P);
             ctx.fillRect(x-5, y-6, 12, P);
         };

         const drawShrine = (x: number, y: number) => {
             // Base
             ctx.fillStyle = C_STONE_SHADOW;
             ctx.fillRect(x-10, y, 20, 10);
             // Mid
             ctx.fillStyle = C_STONE_MAIN;
             ctx.fillRect(x-8, y-15, 16, 15);
             // Top (Roof)
             ctx.fillStyle = C_STONE_SHADOW;
             ctx.fillRect(x-12, y-20, 24, 5);
             ctx.fillStyle = C_STONE_MAIN;
             ctx.fillRect(x-10, y-25, 20, 5);
             // Detail
             ctx.fillStyle = '#333';
             ctx.fillRect(x-3, y-12, 6, 6); // Dark opening
         };

         const drawChest = (x: number, y: number) => {
             const w = 24; const h = 16;
             // Body
             ctx.fillStyle = C_WOOD;
             ctx.fillRect(x-w/2, y-h, w, h);
             // Trim (Iron)
             ctx.fillStyle = '#555';
             ctx.fillRect(x-w/2, y-h, w, P); // Lid rim
             ctx.fillRect(x-w/2, y-P, w, P); // Bottom rim
             ctx.fillRect(x-w/2 + w/2 - P, y-h+2, P*2, 6); // Lock
             ctx.fillStyle = '#333';
             ctx.fillRect(x-w/2 + w/2 - 1, y-h+4, 2, 2); // Keyhole
         };


         // Draw objects in Y-order (simple sort not strictly needed for static map, but good practice)
         // We just iterate our obstacles list which is mixed.
         // We'll draw them based on type.
         
         OBSTACLES.forEach(obs => {
             if (obs.type === 'tree') drawTree(obs.x, obs.y, obs.r);
             else if (obs.type === 'bush') drawBush(obs.x, obs.y, obs.r);
             else if (obs.type === 'sign') drawSign(obs.x, obs.y);
             else if (obs.type === 'shrine') drawShrine(obs.x, obs.y);
             else if (obs.type === 'chest') drawChest(obs.x, obs.y);
             else if (obs.type === 'rock') {
                 ctx.fillStyle = C_STONE_SHADOW;
                 ctx.fillRect(obs.x-5, obs.y-5, 10, 10);
                 ctx.fillStyle = C_STONE_MAIN;
                 ctx.fillRect(obs.x-4, obs.y-6, 8, 8);
             }
         });


         // 6. The Gate (North) - Redesigned as stone ruins/archway
         const gateX = W/2 - 50;
         const gateY = 10;
         // Pillars
         ctx.fillStyle = C_STONE_SHADOW;
         ctx.fillRect(gateX, gateY, 20, 70);
         ctx.fillRect(gateX+80, gateY, 20, 70);
         // Main stone
         ctx.fillStyle = C_STONE_MAIN;
         ctx.fillRect(gateX+2, gateY, 16, 70);
         ctx.fillRect(gateX+82, gateY, 16, 70);
         // Arch
         ctx.fillStyle = C_STONE_SHADOW;
         ctx.fillRect(gateX-5, gateY-5, 110, 20);
         ctx.fillStyle = C_STONE_MAIN;
         ctx.fillRect(gateX, gateY-5, 100, 15);
         // Cracks
         ctx.fillStyle = '#555';
         ctx.fillRect(gateX+10, gateY+30, 2, 10);
         ctx.fillRect(gateX+85, gateY+50, 2, 8);


         // 7. Vignette/Lighting
         const grad = ctx.createRadialGradient(W/2, H/2, H/2, W/2, H/2, W);
         grad.addColorStop(0, 'rgba(0,0,0,0)');
         grad.addColorStop(1, 'rgba(20,30,10,0.3)'); // Dark green tint
         ctx.fillStyle = grad;
         ctx.fillRect(0,0,W,H);

      } else {
         // --- INTRO SCENES (UNCHANGED) ---
         // Keeping the logic exactly as restored in previous step for quality
         
         if (scene === 'title') {
            const grad = ctx.createLinearGradient(0,0,0,H);
            grad.addColorStop(0, '#0f0518'); grad.addColorStop(1, '#4a1236');
            ctx.fillStyle = grad; ctx.fillRect(0,0,W,H);
            ctx.fillStyle = '#ffd700';
            particles.forEach(p => {
                p.y += p.speedY * 0.5; if(p.y < 0) p.y = H;
                ctx.globalAlpha = p.opacity; ctx.fillRect(p.x, p.y, p.size, p.size);
            });
            ctx.globalAlpha = 1.0;
         } else if (scene === 'prison_sunrise') {
            ctx.fillStyle = '#8FB1D6'; ctx.fillRect(0, 0, W, H * 0.6);
            ctx.fillStyle = '#F4C2C2'; ctx.fillRect(0, H * 0.4, W, H * 0.2); 
            ctx.fillStyle = '#6E7F80'; ctx.beginPath(); ctx.moveTo(0, H*0.6); for(let x=0; x<=W; x+=20) ctx.lineTo(x, H*0.6 - Math.sin(x*0.01)*20); ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
            ctx.fillStyle = '#7CAA68'; ctx.fillRect(0, H*0.7, W, H*0.3);
            ctx.fillStyle = '#555'; ctx.fillRect(0, H-150, 300, 150); ctx.fillStyle = '#444'; ctx.fillRect(0, H-150, 300, 10);
            const sx = 350; const sy = H-80;
            ctx.fillStyle = '#A64D43'; ctx.fillRect(sx, sy, 20, 30); ctx.fillStyle = '#3E4C5E'; ctx.fillRect(sx, sy+30, 20, 20); ctx.fillStyle = '#EBC29D'; ctx.fillRect(sx+4, sy-10, 12, 10);
         } else if (scene === 'bus_ride') {
             const shake = Math.sin(frame * 0.5) * 2; ctx.save(); ctx.translate(0, shake);
             ctx.fillStyle = '#B5D6E0'; ctx.fillRect(0, 0, W, H);
             ctx.fillStyle = '#7CAA68'; const offset = (frame * 10) % W; ctx.fillRect(0, H*0.6, W, H*0.4); 
             ctx.fillStyle = '#2f3a28'; if ((frame % 40) < 5) ctx.fillRect(W - offset, H*0.5, 40, 100);
             ctx.fillStyle = '#ddd'; ctx.fillRect(0, 0, W, 60); ctx.fillRect(0, H-100, W, 100); ctx.fillRect(100, 0, 40, H); ctx.fillRect(400, 0, 40, H);
             const sx = 200; const sy = H-80;
             ctx.fillStyle = '#5D6E8C'; ctx.fillRect(sx-20, sy, 80, 80); ctx.fillStyle = '#A64D43'; ctx.fillRect(sx, sy+10, 40, 40); ctx.fillStyle = '#4A3B32'; ctx.fillRect(sx+10, sy-10, 20, 20);
             ctx.restore();
         } else if (scene === 'crash') {
             ctx.fillStyle = '#1A1A24'; ctx.fillRect(0, 0, W, H);
             ctx.globalCompositeOperation = 'screen';
             particles.forEach(p => {
                 p.y += p.speedY * 3; p.x += Math.sin(frame * 0.1 + p.y) * 2;
                 if (p.y < 0) { p.y = H; p.x = W/2 + (Math.random()-0.5)*100; }
                 ctx.fillStyle = Math.random() > 0.5 ? '#ff5722' : '#ffc107'; ctx.fillRect(p.x, p.y, p.size * 3, p.size * 3);
             });
             ctx.globalCompositeOperation = 'source-over';
             ctx.fillStyle = '#000'; ctx.save(); ctx.translate(W/2, H-50); ctx.rotate(0.2); ctx.fillRect(-100, -50, 200, 100); ctx.restore();
         } else if (scene === 'hospital_coma') {
             ctx.fillStyle = '#1e2b3e'; ctx.fillRect(0,0,W,H);
             ctx.fillStyle = '#fff'; ctx.fillRect(W/2 - 100, H/2, 200, 80); ctx.fillStyle = '#ddd'; ctx.fillRect(W/2 - 80, H/2 + 20, 160, 60);
             ctx.fillStyle = '#EBC29D'; ctx.fillRect(W/2 - 90, H/2 - 10, 30, 30);
             ctx.fillStyle = '#111'; ctx.fillRect(W/2 - 200, H/2 - 50, 60, 60);
             ctx.strokeStyle = '#0f0'; ctx.lineWidth = 2; ctx.beginPath();
             const beat = (frame * 2) % 60; const lineX = W/2 - 195 + beat;
             ctx.moveTo(W/2 - 195, H/2 - 20);
             if (beat < 50) ctx.lineTo(lineX, H/2 - 20); else ctx.lineTo(lineX, H/2 - 20 - (Math.random()*10));
             ctx.stroke();
         } else if (scene === 'void' || scene === 'abyss') {
             ctx.fillStyle = '#000'; ctx.fillRect(0,0,W,H);
             ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; const cx = W/2; const cy = H/2;
             for(let i=0; i<5; i++) {
                 const r = 50 + i*30 + Math.sin(frame * 0.05 + i)*10;
                 ctx.globalAlpha = 0.2; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI*2); ctx.stroke();
             }
             ctx.fillStyle = '#fff'; ctx.globalAlpha = 0.8; ctx.fillRect(cx - 10, cy - 10, 20, 40);
         }
      }

      animationId = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(animationId);
  }, [mode, introIndex]);

  return (
      <canvas 
        ref={canvasRef} 
        className="block w-full h-full object-contain bg-black"
        style={{ imageRendering: 'pixelated' }}
      />
  );
};

// --- PLAYER SPRITE ---

interface PlayerSpriteProps {
    direction: Direction;
    isMoving: boolean;
    frame: number;
    isAttacking: boolean;
    isDefending: boolean;
}

const PlayerSprite: React.FC<PlayerSpriteProps> = ({ direction, isMoving, frame, isAttacking, isDefending }) => {
    const animOffset = isMoving ? (Math.floor(frame / 8) % 2) * 2 : 0;
    
    // Attack rotation for simple swing logic
    const swingRotation = isAttacking ? (direction === 'left' ? -45 : 45) : 0;
    const swingOrigin = direction === 'left' ? 'bottom right' : 'bottom left';

    return (
        <div className="relative w-full h-full" style={{ transform: `translateY(${animOffset}px)` }}>
            {/* Soft Shadow */}
            <div className="absolute bottom-[2%] left-[10%] w-[80%] h-[15%] bg-black/30 rounded-full blur-[2px]"></div>
            
            {/* Legs */}
            <div className="absolute bottom-[5%] left-[20%] w-[25%] h-[30%] bg-[#3E4C5E]"></div>
            <div className="absolute bottom-[5%] right-[20%] w-[25%] h-[30%] bg-[#3E4C5E]"></div>
            
            {/* Torso */}
            <div className="absolute bottom-[30%] left-[10%] w-[80%] h-[35%] bg-[#A64D43] rounded-sm relative">
                {/* Shield for Defending */}
                {isDefending && (
                   <div className={`absolute top-[10%] ${direction === 'left' ? '-left-[40%]' : '-right-[40%]'} w-[60%] h-[80%] bg-[#5d6b7c] border-2 border-[#eee] rounded-sm z-20 shadow-md flex items-center justify-center`}>
                       <div className="w-[60%] h-[60%] bg-[#A64D43] rounded-full"></div>
                   </div> 
                )}
            </div>
            
            {/* Arms */}
            <div className="absolute bottom-[30%] left-[0%] w-[20%] h-[30%] bg-[#8C3D35] rounded-full"></div>
            <div className="absolute bottom-[30%] right-[0%] w-[20%] h-[30%] bg-[#8C3D35] rounded-full">
                {/* Sword for Attacking */}
                {isAttacking && (
                    <div 
                        className="absolute bottom-[-20%] left-[50%] w-[200%] h-[20%] bg-white origin-bottom-left animate-ping"
                        style={{ 
                            transform: `rotate(${swingRotation}deg)`, 
                            transformOrigin: swingOrigin,
                            boxShadow: '0 0 10px #fff'
                        }}
                    >
                         {/* Visual Sword */}
                         <div className="absolute bottom-0 left-0 w-[20%] h-[400%] bg-gray-300 -translate-y-[80%] origin-bottom transform rotate-45 border border-white"></div>
                    </div>
                )}
            </div>

            {/* Head (Slightly larger for chibi/cozy style) */}
            <div className="absolute bottom-[60%] left-[10%] w-[80%] h-[35%] bg-[#EBC29D] rounded-sm shadow-sm z-10"></div>
            
            {/* Hair */}
            <div className="absolute top-[0%] left-[5%] w-[90%] h-[25%] bg-[#4A3B32] rounded-t-sm z-10"></div>
            <div className="absolute top-[10%] left-[5%] w-[20%] h-[40%] bg-[#4A3B32] z-10"></div> 
            <div className="absolute top-[10%] right-[5%] w-[20%] h-[40%] bg-[#4A3B32] z-10"></div>

            {/* Face */}
            {(direction === 'down' || direction === 'left' || direction === 'right') && (
                <>
                <div className="absolute top-[35%] left-[25%] w-[10%] h-[10%] bg-black opacity-80 z-10"></div>
                <div className="absolute top-[35%] right-[25%] w-[10%] h-[10%] bg-black opacity-80 z-10"></div>
                </>
            )}
            
            {/* Attack Swipe Effect (Overlay) */}
            {isAttacking && (
                <div 
                    className={`absolute top-[-20%] ${direction==='left' ? '-left-[60%]' : '-right-[60%]'} w-[100%] h-[120%] border-t-4 border-white rounded-full opacity-80 z-30`}
                    style={{ transform: `rotate(${direction === 'left' ? '-45deg' : '45deg'})` }}
                ></div>
            )}
        </div>
    );
};

// --- MAIN APP COMPONENT ---

const App: React.FC = () => {
  const [screen, setScreen] = useState<'title' | 'intro' | 'chapter_one' | 'game'>('title');
  const [language, setLanguage] = useState<'en' | 'es'>('en');
  const [introIndex, setIntroIndex] = useState(0);

  // GAME STATE
  const [player, setPlayer] = useState({ 
      x: 320, 
      y: 180, 
      direction: 'down' as Direction, 
      isMoving: false, 
      frame: 0,
      isAttacking: false,
      isDefending: false
  });
  
  const [day, setDay] = useState(1);
  const [spiritMessage, setSpiritMessage] = useState<string>("");
  const [showSpiritMessage, setShowSpiritMessage] = useState(false);

  const keysPressed = useRef<Record<string, boolean>>({});

  // --- CONTROLS & PHYSICS ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        keysPressed.current[e.key.toLowerCase()] = true;
        if ((e.key === ' ' || e.key === 'Enter') && screen === 'game') handleInteraction();
    };
    const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key.toLowerCase()] = false; };
    
    // Mouse Controls for Combat
    const handleMouseDown = (e: MouseEvent) => {
        if (screen !== 'game') return;
        
        // Left Click: Attack
        if (e.button === 0 && !player.isDefending && !player.isAttacking) {
            setPlayer(prev => ({ ...prev, isAttacking: true }));
            // Reset attack after animation
            setTimeout(() => {
                setPlayer(prev => ({ ...prev, isAttacking: false }));
            }, 300);
        }
        
        // Right Click: Defend
        if (e.button === 2 && !player.isAttacking) {
            setPlayer(prev => ({ ...prev, isDefending: true }));
        }
    };

    const handleMouseUp = (e: MouseEvent) => {
         if (screen !== 'game') return;
         if (e.button === 2) {
             setPlayer(prev => ({ ...prev, isDefending: false }));
         }
    };
    
    // Prevent Context Menu on Right Click
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('contextmenu', handleContextMenu);
    
    return () => {
        window.removeEventListener('keydown', handleKeyDown);
        window.removeEventListener('keyup', handleKeyUp);
        window.removeEventListener('mousedown', handleMouseDown);
        window.removeEventListener('mouseup', handleMouseUp);
        window.removeEventListener('contextmenu', handleContextMenu);
    };
  }, [screen, player.isAttacking, player.isDefending]);

  // GAME LOOP
  useEffect(() => {
    if (screen !== 'game') return;
    let loopId: number;
    const speed = 3.0; 

    const loop = () => {
        setPlayer(prev => {
            // Block movement if performing an action
            if (prev.isAttacking || prev.isDefending) {
                return { ...prev, isMoving: false };
            }

            let { x, y, direction, isMoving, frame } = prev;
            let dx = 0;
            let dy = 0;
            let newIsMoving = false;

            if (keysPressed.current['w'] || keysPressed.current['arrowup']) { dy -= speed; direction = 'up'; newIsMoving = true; }
            if (keysPressed.current['s'] || keysPressed.current['arrowdown']) { dy += speed; direction = 'down'; newIsMoving = true; }
            if (keysPressed.current['a'] || keysPressed.current['arrowleft']) { dx -= speed; direction = 'left'; newIsMoving = true; }
            if (keysPressed.current['d'] || keysPressed.current['arrowright']) { dx += speed; direction = 'right'; newIsMoving = true; }

            // Normalize diagonal
            if (dx !== 0 && dy !== 0) { dx *= 0.707; dy *= 0.707; }

            let nextX = x + dx;
            let nextY = y + dy;

            // --- COLLISION LOGIC ---
            
            // 1. World Bounds (Canvas edges)
            if (nextX < 20) nextX = 20;
            if (nextX > CANVAS_W - 20) nextX = CANVAS_W - 20;
            if (nextY < 20) nextY = 20;
            if (nextY > CANVAS_H - 10) nextY = CANVAS_H - 10;

            // 2. The Gate (Top Center - Custom logic)
            // Rect: x: 260-380, y: 0-90
            if (nextX > 260 && nextX < 380 && nextY < 80) {
                if (dy < 0) nextY = y; 
                if (dx !== 0 && nextY < 80) nextX = x;
            }

            // 3. Centralized Obstacles (Trees, Ruins)
            OBSTACLES.forEach(obs => {
                const dist = Math.sqrt((nextX - obs.x)**2 + (nextY - obs.y)**2);
                // Simple circle collision
                if (dist < obs.r + 15) { 
                     nextX = x; nextY = y; 
                }
            });

            return { x: nextX, y: nextY, direction, isMoving: newIsMoving, frame: newIsMoving ? frame + 1 : 0, isAttacking: prev.isAttacking, isDefending: prev.isDefending };
        });
        loopId = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(loopId);
  }, [screen]);

  const handleInteraction = async () => {
      if (!showSpiritMessage) {
        setSpiritMessage("...");
        setShowSpiritMessage(true);
        const msg = await getForestSpiritMessage(day, 100);
        setSpiritMessage(msg);
      } else {
          setShowSpiritMessage(false);
      }
  };

  const handleStartIntro = (lang: 'en' | 'es') => { setLanguage(lang); setScreen('intro'); setIntroIndex(0); };
  const handleIntroClick = () => {
    const script = INTRO_SCRIPT[language];
    if (introIndex < script.length - 1) setIntroIndex(prev => prev + 1);
    else setScreen('chapter_one');
  };
  useEffect(() => {
    if (screen === 'chapter_one') {
      const timer = setTimeout(() => handleStartGame(), 4000);
      return () => clearTimeout(timer);
    }
  }, [screen]);
  const handleStartGame = () => {
    setScreen('game');
    setSpiritMessage(language === 'en' ? "The silence is heavy, but the ground feels warm." : "El silencio pesa, pero la tierra se siente cálida.");
    setShowSpiritMessage(true);
    setTimeout(() => setShowSpiritMessage(false), 5000);
  };

  // --- RENDER ---

  // Title Screen
  if (screen === 'title') {
    return (
      <div className="h-screen w-screen bg-black flex flex-col items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-50"><PixelCanvas mode="title" /></div>
        <div className="z-10 flex flex-col items-center gap-8">
           <h1 className="text-6xl text-white pixel-text tracking-widest text-center shadow-black drop-shadow-lg">Price Of Sin</h1>
           <div className="flex gap-4">
            <button onClick={() => handleStartIntro('en')} className="pixel-text text-xl text-white border-2 border-white px-4 py-2 hover:bg-white hover:text-black transition-colors">English</button>
            <button onClick={() => handleStartIntro('es')} className="pixel-text text-xl text-white border-2 border-white px-4 py-2 hover:bg-white hover:text-black transition-colors">Español</button>
           </div>
        </div>
      </div>
    );
  }

  // Intro
  if (screen === 'intro') {
    return (
      <div className="h-screen w-screen bg-black flex flex-col items-center justify-center cursor-pointer relative" onClick={handleIntroClick}>
        <div className="w-[85vw] aspect-video border-4 border-[#333] bg-black relative shadow-[0_0_50px_rgba(0,0,0,0.5)]">
            <PixelCanvas mode="intro" introIndex={introIndex} />
            <div className="absolute bottom-0 w-full bg-black/80 p-8 border-t-4 border-white/20">
                <p className="text-4xl text-[#ccc] pixel-text leading-relaxed whitespace-pre-wrap drop-shadow-md">{INTRO_SCRIPT[language][introIndex]}</p>
                <div className="text-right text-xl text-white/40 animate-pulse mt-4">▼</div>
            </div>
        </div>
      </div>
    );
  }

  // Chapter Card
  if (screen === 'chapter_one') {
    return (
      <div className="h-screen w-screen bg-black flex items-center justify-center animate-in fade-in duration-1000">
        <div className="text-center">
           <h1 className="text-white text-5xl pixel-text tracking-[0.3em] uppercase mb-6">{language === 'en' ? 'Chapter One' : 'Capítulo Uno'}</h1>
           <p className="text-[#888] text-2xl pixel-text tracking-[0.5em] uppercase">Limbo</p>
        </div>
      </div>
    );
  }

  // Game (Limbo - Cozy Style)
  return (
    <div className="h-screen w-screen bg-[#1a1814] flex items-center justify-center p-4">
      {/* Game Container */}
      <div className="relative w-full max-w-[1280px] aspect-video bg-[#0f0e0d] shadow-2xl border-4 border-[#2b2520] overflow-hidden">
         
         {/* Layer 1: Background Canvas */}
         <div className="absolute inset-0 w-full h-full">
            <PixelCanvas mode="game" />
         </div>

         {/* Layer 2: Entities (Player) */}
         <div 
            className="absolute z-10 pointer-events-none transition-transform duration-75 ease-linear"
            style={{ 
                left: `${(player.x / CANVAS_W) * 100}%`, 
                top: `${(player.y / CANVAS_H) * 100}%`,
                width: `${(32 / CANVAS_W) * 100}%`,
                transform: 'translate(-50%, -90%)' 
            }}
         >
             <div className="w-full pb-[150%] relative">
                <div className="absolute inset-0">
                    <PlayerSprite 
                        direction={player.direction} 
                        isMoving={player.isMoving} 
                        frame={player.frame}
                        isAttacking={player.isAttacking}
                        isDefending={player.isDefending}
                    />
                </div>
             </div>
         </div>

         {/* Layer 3: Minimal UI Overlay (No Bars, only Spirit Text) */}
         {showSpiritMessage && (
            <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-auto max-w-3xl bg-transparent animate-in slide-in-from-bottom-2 fade-in">
                <p className="text-[#e8e6d1] pixel-text text-2xl text-center leading-relaxed font-bold tracking-wider drop-shadow-[2px_2px_0_rgba(0,0,0,0.8)] bg-black/40 px-6 py-3 rounded-lg backdrop-blur-sm border border-white/10">
                    {spiritMessage}
                </p>
            </div>
         )}
      </div>
    </div>
  );
};

export default App;
