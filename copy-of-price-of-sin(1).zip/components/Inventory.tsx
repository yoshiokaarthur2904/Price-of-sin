
import React from 'react';
import { InventoryItem } from '../types';

interface InventoryProps {
  items: InventoryItem[];
  selectedIndex: number;
  onSelect: (index: number) => void;
}

const Inventory: React.FC<InventoryProps> = ({ items, selectedIndex, onSelect }) => {
  return (
    <div className="flex gap-1 p-2 stardew-wood rounded-none">
      {Array.from({ length: 10 }).map((_, idx) => {
        const item = items[idx];
        const isSelected = selectedIndex === idx;
        
        return (
          <div 
            key={idx}
            onClick={() => onSelect(idx)}
            className={`
              w-14 h-14 flex flex-col items-center justify-center relative cursor-pointer transition-all
              ${isSelected 
                ? 'scale-110 border-4 border-yellow-300 bg-[#ffeb3b]/20 z-10 shadow-[0_0_15px_rgba(255,235,59,0.5)]' 
                : 'bg-black/20 border-2 border-black/40'}
              hover:bg-white/10 rounded-none
            `}
          >
            {item ? (
              <>
                <span className="text-3xl drop-shadow-md">{item.icon}</span>
                {item.count > 1 && (
                  <span className="absolute bottom-0 right-1 text-sm font-bold text-white pixel-text drop-shadow-[1px_1px_0_rgba(0,0,0,1)]">
                    {item.count}
                  </span>
                )}
              </>
            ) : null}
          </div>
        );
      })}
    </div>
  );
};

export default Inventory;
