
import React from 'react';
import { TileState, CropType } from '../types';
import { CROPS_DATA } from '../constants';

interface TileProps {
  tile: TileState;
  onClick: () => void;
}

const Tile: React.FC<TileProps> = ({ tile, onClick }) => {
  const getTileClass = () => {
    let base = "w-full h-full border border-black/5 flex items-center justify-center transition-all duration-100 cursor-pointer ";
    if (tile.type === 'grass') return base + "grass-tile hover:brightness-110";
    if (tile.type === 'soil') return base + `soil-tile ${tile.isWatered ? 'soil-watered' : ''} hover:brightness-105`;
    if (tile.type === 'water') return base + "water-tile";
    return base;
  };

  const renderCrop = () => {
    if (!tile.crop) return null;
    const { growthStage, type } = tile.crop;
    
    // Better visual progression
    if (growthStage === 0) return <span className="text-sm">🌱</span>;
    if (growthStage === 1) return <span className="text-xl">🌿</span>;
    if (growthStage === 2) return <span className="text-2xl drop-shadow-sm">🌾</span>;
    if (growthStage === 3) return <div className="animate-bounce"><span className="text-4xl drop-shadow-lg">{CROPS_DATA[type].icon}</span></div>;
    return null;
  };

  return (
    <div 
      className={getTileClass()} 
      onClick={onClick}
    >
      <div className="relative w-full h-full flex items-center justify-center">
        {renderCrop()}
      </div>
    </div>
  );
};

export default Tile;
